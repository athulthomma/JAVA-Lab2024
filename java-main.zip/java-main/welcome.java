class welcome{
	public static void main(String[] args){
		System.out.print("WELCOME JAVA");
	}
}
